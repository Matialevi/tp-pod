package domain;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class test{
	
	@Test
    public void papel_vs_piedra() {
    	Juego unJuego = new Juego("Jugador A", "Jugador B");
        Jugada piedra = new Piedra();
        Jugada papel = new Papel();
        boolean resultado = unJuego.jugar(papel, piedra);
        assertTrue(resultado, "El papel gana a la piedra");
    }


    public void tijera_vs_piedra() {
    	Juego unJuego = new Juego("Jugador A", "Jugador B");
        Jugada piedra = new Piedra();
        Jugada tijera = new Tijera();
        boolean resultado = unJuego.jugar(piedra, tijera);
        assertFalse(resultado, "La tijera no le gana a la piedra");
    }


    public void lagarto_vs_papel() {
    	Juego unJuego = new Juego("Jugador A", "Jugador B");
        Jugada lagarto = new Lagarto();
        Jugada papel = new Papel();
        boolean resultado = unJuego.jugar(lagarto, papel);
        assertTrue(resultado, "El lagarto le gana al papel");
    }


    public void spock_vs_spock() {
    	Juego unJuego = new Juego("Jugador A", "Jugador B");
        Jugada spock = new Spock();
        boolean resultado = unJuego.jugar(spock, spock);
        assertFalse(resultado, "El spock empata contra spock");
    }

}

