package domain;

public class Juego {
	
	private String jugadorA;
    private String jugadorB;

    public Juego(String jugadorA, String jugadorB) {
        this.jugadorA = jugadorA;
        this.jugadorB = jugadorB;
    }
    
    
    public boolean jugar(Jugada jugadaA, Jugada jugadaB) {
        boolean resultado = jugadaA.le_juega_a(jugadaB);
    	return resultado;
	}
}
