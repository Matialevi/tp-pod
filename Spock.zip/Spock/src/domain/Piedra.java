package domain;

public class Piedra extends Jugada {
    
    public boolean le_juega_a(Jugada otra) {
    	return otra instanceof Tijera || otra instanceof Lagarto;
    }
}
