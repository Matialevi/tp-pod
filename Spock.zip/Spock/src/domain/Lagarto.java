package domain;

public class Lagarto extends Jugada {
    
    public boolean le_juega_a(Jugada otra) {
    	return otra instanceof Papel || otra instanceof Spock;
    }
}
