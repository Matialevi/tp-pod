package domain;

public abstract class Jugada {

    public abstract boolean le_juega_a(Jugada otra);
}
