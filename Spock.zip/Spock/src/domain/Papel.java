package domain;

public class Papel extends Jugada {
    
    public boolean le_juega_a(Jugada otra) {
    	return otra instanceof Piedra || otra instanceof Spock;
    }
}
