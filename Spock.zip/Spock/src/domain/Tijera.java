package domain;

public class Tijera extends Jugada {
    
    public boolean le_juega_a(Jugada otra) {
    	return otra instanceof Papel || otra instanceof Lagarto;
    }
}
