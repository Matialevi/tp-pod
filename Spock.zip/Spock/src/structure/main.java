package structure;

import domain.*;

public class main {
	
	public static void main(String[] args) {
		Juego unJuego = new Juego("Jugador A", "Jugador B");
		Jugada piedra = new Piedra();
		Jugada papel = new Papel();
		Jugada tijera = new Tijera();
		Jugada lagarto = new Lagarto();
		Jugada spock = new Spock();
		
		System.out.println(unJuego.jugar(spock, piedra));
	}

}